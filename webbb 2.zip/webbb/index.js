    function Pass11() {
        var textInBox4 = document.getElementById("testing").value;
        var textInBox5 = document.getElementById("testing").value;
        if (textInBox4 === nathan && textInBox5 === hello)
            window.location.replace('about.html');
        }else
            alert("Wrong Username or Password, Pls Try Again");

